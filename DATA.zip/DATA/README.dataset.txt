# PFE > 2023-09-22 12:45pm
https://universe.roboflow.com/raja-xwpuo/pfe-82dqp

Provided by a Roboflow user
License: CC BY 4.0

